#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "stack.h"

int main(int argc, char** argv)
{
    // Create a stack
    Stack* S = initStack();

    printf("Please enter numbers separated by spaces or 'enter', -1 when done.\n");
    while (true) {   // Loop until 'break'
    	int num = 0;
    	scanf("%d", &num);
    	if (num == -1) {  // Check loop exit condition
    		break;
		}
        push(S, num);    	
	}
    
    // Pop and print all the numbers
    printf("\n");
    while (!isEmpty(S)) {
        int num = pop(S);
        printf("%d\n", num);
    }
}

