#include <stdio.h>
#include <stdlib.h>

double* arr;   // Dynamic array

// Comparison function
int cmpfunc(const void* a, const void* b) {
    double num1 = *(double*)a;
    double num2 = *(double*)b;
    if (num1 > num2) {
    	return 1;
	}
	else if (num2 > num1) {
		return -1;
	}
	else {
		return 0;
	}
}

// Two functions to implement Heap sort
void ReHeap(int len, int parent) {
    double temp = arr[parent];
    int child = 2*parent + 1;
    while (child < len) {
        if (child<len-1 && arr[child]<arr[child+1])
            child++;
        if (temp >= arr[child])
            break;
        arr[parent] = arr[child];
        parent = child;
        child = 2*parent + 1;
    }
    arr[parent] = temp;
}

void HeapSort(int n) {
    for (int i = n/2; i>= 0; i--)
        ReHeap(n, i);
    for (int i = n-1; i> 0; i--) {
        double temp = arr[i];   // Swap
		arr[i] = arr[0];
		arr[0] = temp;
        ReHeap(i, 0);
    }
}

int main(int argc, char** argv) {
	int size = 6;
	
	// Allocate an array of doubles size 'size' on the heap
	arr = malloc(size * sizeof(double));
	
	// Fill array
	printf("Please enter %d numbers: ", size);
	for(int i = 0; i < size; i++) {
		scanf("%lf", &arr[i]);
	}
	
    qsort(arr, size, sizeof(double), cmpfunc);  // Sort the array "in place"

	for(int i = 0; i < size; i++) {   // Print array contents
		printf("%g ", arr[i]);
	}
	printf("\n");
	
	// Enlarge the array
	int oldSize = size;     // Remember the old size
	size = size * 2;
	arr = realloc(arr, size * sizeof(double));

	// Fill new part of array
	printf("Please enter %d more numbers: ", size-oldSize);
	for(int i = oldSize; i < size; i++) {
		scanf("%lf", &arr[i]);
	}
	
	HeapSort(size);  // Sort with heap sort
	
	for(int i = 0; i < size; i++) {   // Print array contents
		printf("%g ", arr[i]);
	}
	printf("\n");
		
	free(arr);
}
