#include <stdio.h>
#include <string.h>

// Encode each character in 'str' using exclusive-or.
void encode(char str[])
{
    int len = strlen(str);
    for (int index = 0; index < len; index++) {
        str[index] = str[index] ^ 0x5A;
    }
}

int main(int argc, char** argv) {
    // Input a string
    printf("Please enter a message: ");
    char msg[100];
    scanf("%99s", msg);

    printf("You entered: %s\n", msg);

    // Encode the message
    encode(msg);
    printf("The encoded message is: %s\n", msg);
    
    // Decode the message by encoding again
    encode(msg);
    printf("The decoded message is: %s\n", msg);
}

