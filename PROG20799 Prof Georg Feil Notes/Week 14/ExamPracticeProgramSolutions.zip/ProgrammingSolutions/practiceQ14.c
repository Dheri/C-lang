#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define MAX_WORD_SIZE 100

typedef struct{
    char word[MAX_WORD_SIZE];
} NodeData;

typedef struct treenode {
    NodeData data;  // struct inside a struct
    struct treenode* left;
    struct treenode* right;
} TreeNode;

typedef struct {
    TreeNode* root;  // Root of the tree
} BinaryTree;

// Create a new dynamically allocated tree node containing given node data.
// Note: This program does not correctly free allocated memory.
TreeNode* newTreeNode(NodeData node) {
    TreeNode* p = (TreeNode*) malloc(sizeof(TreeNode));
    p->data = node;  // Copies the node
    p->left = p->right = NULL;
    return p;
}

// Used to build a binary search tree.
// Returns a pointer to TreeNode if node 'd' was found, NULL otherwise.
TreeNode* findOrInsert(BinaryTree bt, NodeData d) {
    if (bt.root == NULL)
        return newTreeNode(d);
    TreeNode* curr= bt.root;
    int cmp;
    while ((cmp = strcmp(d.word, curr-> data.word)) != 0) {
        if (cmp < 0) { // try left
            if (curr->left == NULL) {
                curr->left = newTreeNode(d);  // Not found, insert new node
                return NULL;
			}
            curr= curr-> left;
        } else if (cmp > 0) { // try right
            if (curr->right == NULL) {
                curr->right = newTreeNode(d); // Not found, insert new node
                return NULL;
			}
            curr= curr->right;
        }
    }
    printf("Node was found\n"); // if we reach here, d was found in the tree!
    return curr; 
}

int main(int argc, char** argv) {
    char word[MAX_WORD_SIZE];
    BinaryTree bt;
    bt.root = NULL;
    
    printf("Please enter words to build the tree. Enter X to finish.\n");
    while (true) {
    	// Input a word
        int cnt = scanf("%s", word);
        if (cnt != 1 || strcmp(word, "X") == 0)
            break;
            
        // Create a node containing the word
        NodeData nodedat;
        strcpy(nodedat.word, word);
        
        // Add it to the BST
        if (bt.root == NULL) {
            bt.root = newTreeNode(nodedat);
        } else {
            findOrInsert(bt, nodedat);
        }
    }

    printf("Please enter words to find in the tree. Enter X to finish.\n");
    while (true) {
    	// Input a word
        int cnt = scanf("%s", word);
        if (cnt != 1 || strcmp(word, "X") == 0)
            break;
            
        // Create a node containing the word
        NodeData nodedat;
        strcpy(nodedat.word, word);
        
        // Find it in the BST (we assume the tree is already built and root is not null).
		// If not found it will be inserted.
        TreeNode* node = findOrInsert(bt, nodedat);
        if (node == NULL) {
        	printf("Node was not found (inserted)\n");  // Note: Node was found already printed
		}
    }
}


